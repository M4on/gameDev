export default class Paddle {
  constructor(game_width, game_height) {
    this.width = 150;
    this.height = 15;

    this.position = {
      x: game_width / 2 - this.width / 2,
      y: game_height - this.height - 10
    };
  }

  draw(ctx) {
    ctx.fillStyle = "#0f0";
    ctx.fillRect(this.position.x, this.position.y, this.width, this.height);
  }
}
